import React from 'react';
import { Hero } from './components/Hero';
import { Info } from './components/Info';
import { Features } from './components/Features';
import { Comparison } from './components/Comparison';
import { Industries } from './components/Industries';
import { CallToAction } from './components/CallToAction';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

function App() {
  return (
    <div className="min-h-screen bg-gray-900">
      <Hero />
      <Info />
      <Features />
      <Comparison />
      <Industries />
      <CallToAction />
      <FloatingWhatsApp />
    </div>
  );
}

export default App;