import React from 'react';
import { X, Check } from 'lucide-react';

const benefits = [
  'Um sistema completo, fácil de usar e totalmente adaptável',
  'Personalização conforme necessidade',
  'Integração com NFe/NFCe/CTe',
  'Desenvolvido para o mercado brasileiro',
  'Multi-empresas e multi-filiais',
  'Controle de permissões por usuário',
  'Atualizações constantes',
  'Suporte técnico especializado',
  'Backups automáticos',
  'Interface intuitiva'
];

export function Comparison() {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4 max-w-6xl">
        <h2 className="text-3xl font-bold text-center mb-12 text-white">
          Por que escolher o ORIUM ERP?
        </h2>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="p-6 bg-gray-900 rounded-lg border border-gray-700">
            <h3 className="text-xl font-semibold mb-6 text-white">Outros sistemas ERP oferecem:</h3>
            <div className="flex items-center gap-3 text-gray-300">
              <X className="w-5 h-5 text-red-500" />
              <span>Um sistema antigo, difícil de mexer</span>
            </div>
          </div>
          <div className="p-6 bg-gray-900 rounded-lg border border-gray-700">
            <h3 className="text-xl font-semibold mb-6 text-white">O que a ORIUM oferece:</h3>
            <div className="space-y-4">
              {benefits.map((benefit) => (
                <div key={benefit} className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-300">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}