import React from 'react';
import { Button } from './Button';

function BackgroundEffect() {
  return (
    <div className="absolute inset-0 overflow-hidden opacity-20">
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/30 rounded-full mix-blend-multiply filter blur-3xl animate-blob" />
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-blue-600/20 rounded-full mix-blend-multiply filter blur-3xl animate-blob" style={{ animationDelay: "2s" }} />
      <div className="absolute bottom-1/4 left-1/2 w-96 h-96 bg-blue-400/20 rounded-full mix-blend-multiply filter blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
    </div>
  );
}

export function Hero() {
  return (
    <section className="relative bg-gray-900 text-white py-20 lg:py-32 overflow-hidden">
      <BackgroundEffect />
      
      {/* Content */}
      <div className="container mx-auto px-4 max-w-6xl relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6 leading-tight">
            SISTEMA ERP INTELIGENTE PARA EMPRESAS: ADAPTÁVEL E FÁCIL DE USAR
          </h1>
          <p className="text-xl lg:text-2xl text-gray-300 mb-8">
            Sistema ERP completo para controle financeiro, estoque, vendas e muito mais. 
            Altamente exclusivo, com suporte VIP garantido.
          </p>
          <Button href="https://wa.me/5543999294587?text=Ol%C3%A1%2C%20eu%20vim%20pelo%20Google%20e%20gostaria%20de%20saber%20mais%20sobre%20o%20seu%20ERP">
            Entre em Contato
          </Button>
        </div>
      </div>
    </section>
  );
}