import React from 'react';
import { ArrowRight } from 'lucide-react';

interface ButtonProps {
  children: React.ReactNode;
  href: string;
  variant?: 'primary' | 'secondary';
}

export function Button({ children, href, variant = 'primary' }: ButtonProps) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
        variant === 'primary'
          ? 'bg-green-500 text-white hover:bg-green-600'
          : 'bg-green-600 text-white hover:bg-green-700'
      }`}
    >
      {children}
      <ArrowRight className="w-4 h-4" />
    </a>
  );
}