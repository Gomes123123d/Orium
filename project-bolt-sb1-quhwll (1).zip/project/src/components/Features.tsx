import React from 'react';
import { CheckCircle } from 'lucide-react';

const features = [
  'Financeiro', 'Fiscal', 'Vendas', 'Compras', 'Estoque', 'Produção',
  'CRM', 'Faturamento', 'Relatórios Gerenciais', 'Contabilidade'
];

export function Features() {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4 max-w-6xl">
        <h2 className="text-3xl font-bold text-center mb-12 text-white">
          O que o sistema ORIUM tem?
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {features.map((feature) => (
            <div key={feature} className="flex items-center gap-3 p-4 bg-gray-800 rounded-lg shadow-lg border border-gray-700">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="font-medium text-gray-200">{feature}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}