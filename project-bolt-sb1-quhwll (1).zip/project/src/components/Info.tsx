import React from 'react';
import { TrendingUp } from 'lucide-react';

function AnimatedGraph() {
  return (
    <div className="relative h-40 w-full max-w-md mx-auto mb-8">
      <div className="absolute bottom-0 left-0 w-full h-full flex items-end justify-around">
        {[1, 2, 3, 4, 5].map((i) => (
          <div
            key={i}
            className="w-8 bg-gradient-to-t from-green-500 to-green-300 rounded-t-lg"
            style={{
              height: `${i * 20}%`,
              animation: `growUp 2s ease-out ${i * 0.2}s forwards`,
              opacity: 0,
            }}
          />
        ))}
      </div>
      <div className="absolute -right-4 top-0 text-green-500 animate-bounce">
        <TrendingUp className="w-8 h-8" />
      </div>
    </div>
  );
}

export function Info() {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4 max-w-4xl text-center">
        <AnimatedGraph />
        <p className="text-xl leading-relaxed text-gray-300">
          Chega de informações perdidas e processos manuais! Com um ERP integrado, 
          sua empresa elimina retrabalhos e ganha produtividade. Empresas com gestão 
          automatizada comprovadamente aumentam seu faturamento através de processos 
          mais eficientes. Conheça o ORIUM ERP e transforme dados em resultados reais 
          para seu negócio.
        </p>
      </div>
    </section>
  );
}