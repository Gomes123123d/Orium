import React from 'react';
import { MessageCircle } from 'lucide-react';

export function FloatingWhatsApp() {
  return (
    <a
      href="https://wa.me/5543999294587?text=Ol%C3%A1%2C%20eu%20vim%20pelo%20Google%20e%20gostaria%20de%20saber%20mais%20sobre%20o%20seu%20ERP"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition-all z-50 animate-bounce"
    >
      <MessageCircle className="w-6 h-6" />
    </a>
  );
}