import React from 'react';
import { Button } from './Button';

export function CallToAction() {
  return (
    <section className="py-20 bg-gray-800 text-white">
      <div className="container mx-auto px-4 max-w-4xl text-center">
        <h2 className="text-3xl lg:text-4xl font-bold mb-6">
          Transforme a gestão do seu negócio hoje mesmo!
        </h2>
        <p className="text-xl text-gray-300 mb-8">
          Elimine gargalos, ganhe produtividade e mantenha tudo sob controle com o ORIUM ERP. 
          Não perca mais tempo com processos manuais ou sistemas ineficientes. Solicite uma 
          demonstração gratuita agora e veja como simplificar sua rotina pode ser mais fácil 
          do que imagina!
        </p>
        <Button
          href="https://wa.me/5543999294587?text=Ol%C3%A1%2C%20eu%20vim%20pelo%20Google%20e%20gostaria%20de%20saber%20mais%20sobre%20o%20seu%20ERP"
          variant="secondary"
        >
          Solicite uma Demonstração Gratuita
        </Button>
      </div>
    </section>
  );
}