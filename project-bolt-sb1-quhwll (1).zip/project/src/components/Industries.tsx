import React from 'react';
import { Building2 } from 'lucide-react';

const industries = [
  'Indústria', 'Comércio', 'Serviços',
  'Distribuidoras', 'Atacado', 'Varejo'
];

export function Industries() {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4 max-w-6xl">
        <h2 className="text-3xl font-bold text-center mb-12 text-white">
          Setores Atendidos
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {industries.map((industry) => (
            <div key={industry} className="flex items-center gap-3 p-4 bg-gray-800 rounded-lg shadow-lg border border-gray-700">
              <Building2 className="w-5 h-5 text-green-500" />
              <span className="font-medium text-gray-200">{industry}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}