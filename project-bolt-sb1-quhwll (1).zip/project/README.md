# ORIUM ERP

Sistema ERP inteligente para empresas: adaptável e fácil de usar.

## Sobre o Projeto

ORIUM ERP é uma solução completa de gestão empresarial que oferece:

- Controle financeiro
- Gestão de estoque
- Sistema de vendas
- Suporte VIP garantido
- Interface intuitiva e moderna
- Personalização conforme necessidade

## Tecnologias Utilizadas

- React
- TypeScript
- Tailwind CSS
- Vite
- Lucide Icons

## Funcionalidades Principais

- Financeiro
- Fiscal
- Vendas
- Compras
- Estoque
- Produção
- CRM
- Faturamento
- Relatórios Gerenciais
- Contabilidade

## Setores Atendidos

- Indústria
- Comércio
- Serviços
- Distribuidoras
- Atacado
- Varejo

## Contato

Para mais informações ou demonstração, entre em contato via WhatsApp:
[Solicitar Demonstração](https://wa.me/5543999294587?text=Ol%C3%A1%2C%20eu%20vim%20pelo%20Google%20e%20gostaria%20de%20saber%20mais%20sobre%20o%20seu%20ERP)